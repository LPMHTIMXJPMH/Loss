import torch
import torch.nn as nn

import methods

class LossYoLo(nn.Module):
    def __init__(self):
        super(LossYoLo, self).__init__()
        self.metrics = nn.MSELoss(reduction="sum")


    # iou but not non-max-suppression used in coordinates loss calculation
    # non-max-suppresion used in prediction process.
    def moreAccurateOne(self, targets, pred):
        first = pred[..., 21:25];second = pred[..., 26:30] # : [ [ , , , ] , [ , , , ] , [ , , , ] , ... , [ , , , ] ]
        # Maybe two box could help training when the begining prediction is not accurate.
        iou_first = methods.iou_batch(first, targets[..., 21:25]); 
        iou_second = methods.iou_batch(second, targets[..., 21:25])
        ious = torch.cat([iou_first, iou_second], dim = 0)
        # ious: [ [ , ] , [ , ] , [ , ] , ... , [ , ] ]
        _, closer_one = torch.max(ious, dim = 0) # closer_one is one dimension index.
        # return the closer one between two prediction'iou 
        # with target per cell after compare iou_fist and iou_second
        return torch.cat([first, second], dim = 0)[closer_one]


    # shape of pred : [batch size:unknow] [height:7] [width:7] [classes:20 + (confidence score:1 + coordinates:4) * N] 
    # N = 2 when in pred;
    # N = 1 when in target; 
    def forward(self, targets, pred):
        # p or P: prediction respect to target
        # l or L: flatten: turn multi dimension to flatten list

        # brn: To be or not to be. Meaning is there an object.
        brn = targets[..., 20]
        brnL = torch.flatten(brn)

        # what: what object it is.
        what = targets[..., :20]
        whatL = torch.flatten(what)

        # [2:4]: width and height need to be sqrted while x and y don't..
        targets[..., 2:4] = torch.sqrt(targets[..., 2:4])
        # where: coordinates of objects.
        where = targets[..., 21:]
        whereL = torch.flatten(where)
        # Flatten to 1 dimension to calculate the loss.

        ########################
        #== Some or Not loss ==# P stands for prediction
        ########################
        brnP_first = pred[..., 20]; brnP_second = pred[..., 25]
        # P stands for prediction
        brnP_first = torch.flatten(brnP_first)
        brnP_second = torch.flatten(brnP_second)
        # Both two predictions were taken into calculation (in My Choice..)
        some_or_not_loss = (
            self.metrics(brnP_first, brnL) + 
            self.metrics(brnP_second, brnL)) / 2
        ##################
        #== Class loss ==#
        ##################
        whatP = pred[..., :20]
        whatpL = torch.flatten(whatP)
        class_loss = self.metrics(whatpL, whatL)

        ########################
        #== Corrdinates loss ==#
        ########################
        wherePf = self.moreAccurateOne(targets, pred)

        # [2:4]: width and height need to be sqrted while x and y don't..
        wherePf[:, 2:4] = torch.sign(wherePf[2:4]) * torch.sqrt(torch.abs(wherePf[2:4]))

        coord_loss = self.metrics(
            torch.flatten(whereL, end_dim = -2), wherePf)

        #== Total loss ==#
        return ( coord_loss + some_or_not_loss + class_loss * 10 )