def iou(box_first, box_second):
    # yolo box: [0/1, confidence score, x, y, w, h]
    # corners of first box
    left_top_X,left_top_Y,right_bottom_X,right_bottom_Y = box_first[-4:]
    # corners of second box
    left_top_XX, left_top_YY, right_bottom_XX, right_bottom_YY = box_second[-4:]

    # if two bounding box intersected, then calculate intersetion area
    if not (left_top_XX > right_bottom_X or right_bottom_XX < left_top_X) and not (right_bottom_YY < left_top_Y or left_top_YY > right_bottom_Y):
        intersected_left_x  = max(left_top_XX,      left_top_X)
        intersected_right_x = min(right_bottom_XX,  right_bottom_X)
        intersected_top_y   = max(left_top_YY,      left_top_Y)
        intersected_bottom_y= min(right_bottom_YY,  right_bottom_Y)
        # area size of interseted rectangle (or box).
        intersection_area = (intersected_right_x - intersected_left_x) * (intersected_bottom_y - intersected_top_y)

        area_first = (right_bottom_XX - left_top_XX) * (right_bottom_YY - left_top_YY)
        area_second = (right_bottom_X - left_top_X) * (right_bottom_Y - left_top_Y)
        return intersection_area / area_first, intersection_area / area_second

    else: # if two box not contect to each other, both iou is zero.
        iou_first = 0; iou_second = 0
        return iou_first, iou_second
    # 1 / ((1/ iou_first) + (1/ iou_second) -1 ) = iou

# iou calculation with batches.
def iou_batch(boxes_pred, boxes_target):
    intersection = [not (box_second[1]>box_first[3] or box_second[3]<box_first[1]) and not (box_second[4]<box_first[2] or box_second[2]>box_first[4]) for (box_first, box_second) in list(zip(boxes_pred, boxes_target))]

    return [iou(boxes_pred[index], boxes_target[index]) if intersect else None for (index, intersect) in enumerate(intersection)]

    
# For yolo, each cell in the 7*7 cells predict bounding box "twice", so 
# totally we have 98 bounding boxes.And we use "no max supression"
# to select the prediction that are with high score and independent .
def non_max_suppression(
    bboxes,
    threshold_score,
    threshold_iou
):
    # assert type(bboxes) == list
    # bboxes = [[index, confidence score, x1, y1, x2, y2]], box[1]: confidence score
    bboxes = [box for box in bboxes if box[1] > threshold_score]
    # bboxes scores from highest to lowest (both are higher than threshold).
    bboxes = sorted(bboxes, key = lambda x: x[1], reverse = True)

    selected = []
    while bboxes:
        # pop the most high score one from current list
        selected.append(bboxes.pop(0))
        
        for index, box in enumerate(bboxes):
            # -1: last appended highest score
            # 2: coordinate
            # 1: iou of second one -> box
            if iou(selected[-1][2:], box[2:])[1] > threshold_iou:
                del bboxes[index] # box been suppressed.
    
    return selected